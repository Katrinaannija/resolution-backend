#### **Year 2 (Quarterly Invoice)**

*Shows the 20% VAT rate applicable after Jan 2011, leading up to the dispute.*  
**INVOICE** **E-NIK LTD** \[Address\] VAT Reg No: GB 123 456 789  
**Invoice To:** Department for Communities and Local Government Eland House, Bressenden Place London, SW1E 5DU Attn: Head of Procurement  
**Date:** 31 March 2011 **Invoice No:** EN-11-024  
**Description of Services:** Provision of Consultancy Services for GO ICT Systems. Quarterly Consolidation: Jan 2011 \- Mar 2011\. *Includes Analysis and Systems Development.*  
**Details:** Total Days Delivered: 125 Days Daily Rate: £850.00  
**Net Amount:** £106,250.00 **VAT @ 20%:** £21,250.00 **Total Due:** **£127,500.00**  
*Payment due within 30 days of invoice date.*  
