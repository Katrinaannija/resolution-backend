**From:** David Main \[David.Main@communities.gsi.gov.uk\] 

**Sent:** 15 April 2011 

**To:** \[Ms. Dawett / E-Nik Representative\] 

**Subject:** Update on current work / Suspension

Dear Ms. Dawett,

I am afraid that we will have to suspend the current work that you are carrying out.

However, I should note that the current suspension is not an indicator as to what happens next, and does not prejudice and future decision or action.

Regards,

**David Main** Department for Communities and Local Government

