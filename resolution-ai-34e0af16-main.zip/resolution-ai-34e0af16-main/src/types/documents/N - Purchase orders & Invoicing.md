**Appendix 2 to the Fujitsu Agreement**

**Process for Raising Purchase Orders, Invoicing and Payment**

**5\.** The Customer will raise a PO on Fujitsu for the full amount for the services including the paying agent fee.

**6\.** Fujitsu will raise a PO upon the Supplier for the full service charges.

Fujitsu will raise an invoice upon the Customer yearly in advance.

The Supplier will raise an invoice upon Fujitsu yearly in advance.

