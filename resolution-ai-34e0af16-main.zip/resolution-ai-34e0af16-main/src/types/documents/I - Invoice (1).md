**Year 1 (Monthly Invoice)**

*Shows the 15% VAT rate applicable in 2009\.*

**INVOICE** **E-NIK LTD** \[Address\] VAT Reg No: GB 123 456 789

**Invoice To:** Department for Communities and Local Government Eland House, Bressenden Place London, SW1E 5DU Attn: Mr Bentley / Procurement

**Date:** 30 September 2009 **Invoice No:** EN-09-006

**Description of Services:** Provision of Consultancy Services for GO ICT Systems. Project Management and Scoping/Analysis. Period: 1 September 2009 to 30 September 2009\.

**Details:** Total Days Delivered: 48 Days Daily Rate: £850.00

**Net Amount:** £40,800.00 **VAT @ 15%:** £6,120.00 **Total Due:** **£46,920.00**

*Payment due within 30 days of invoice date.*

