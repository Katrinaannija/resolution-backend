**From:** \[Accountant Name\] 

**To:** Ms. Dawett (E-Nik Ltd) 

**Date:** \[Date consistent with hearing preparation, likely late 2012\] 

**Subject:** RE: DCLG Contract / VAT Query

Dear Ms. Dawett,

I can confirm that E-Nik Ltd always quoted the chargeable rate exclusive of VAT. It follows the commercial practice of quoting a rate exclusive of VAT. With regard to the contract with the Department for Communities and Local Government I recall that the contract was settled after extensive discussions with and scrutiny by the Department. The Department was pressing for a standard day rate and at no time did the question of a rate inclusive of VAT was raised by the Department.

Kind regards,

\[Accountant Name\]

