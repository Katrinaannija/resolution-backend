**Year 2 Shortfall (Disputed)**

**INVOICE** **E-NIK LTD** \[Address\] VAT Reg No: GB 123 456 789

**Invoice To:** Department for Communities and Local Government Eland House, Bressenden Place London, SW1E 5DU Attn: Head of Procurement / Finance

**Date:** 09 May 2011 **Invoice No:** EN-11-035

**Description of Services:** **Contract Reconciliation – Year 2 (1 April 2010 – 31 March 2011\)** Charge for the balance of minimum purchased consultancy days not utilized by the Authority.

**Calculation:**

* Minimum Annual Commitment: 500 Days  
* Less: Days called-off and invoiced during period: 4 Days  
* **Balance of Days to be charged: 496 Days**

**Details:** Quantity: 496 Days Daily Rate: £850.00

**Net Amount:** £421,600.00 **VAT @ 20%:** £84,320.00 **Total Due:** **£505,920.00**

*Payment due within 30 days of invoice date.*

