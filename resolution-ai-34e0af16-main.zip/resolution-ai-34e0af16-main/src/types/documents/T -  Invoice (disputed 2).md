### **Invoice – Final Period Minimum (Disputed)**

**INVOICE** **E-NIK LTD** \[Address\] VAT Reg No: GB 123 456 789  
**Invoice To:** Department for Communities and Local Government Eland House, Bressenden Place London, SW1E 5DU Attn: Head of Procurement / Finance  
**Date:** 25 October 2011 **Invoice No:** EN-11-052  
**Description of Services:** **Contract Reconciliation – Final Period (1 April 2011 – 30 September 2011\)** Charge for minimum purchased consultancy days for the final 6-month term.  
**Calculation:**

* Minimum Annual Commitment (Pro-rated for 6 months): 250 Days  
* Less: Days called-off and invoiced during period: 0 Days  
* **Balance of Days to be charged: 250 Days**

**Details:** Quantity: 250 Days Daily Rate: £850.00  
**Net Amount:** £212,500.00 **VAT @ 20%:** £42,500.00 **Total Due:** **£255,000.00**  
*Payment due within 30 days of invoice date.*  
