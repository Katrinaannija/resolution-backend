**From:** Mr Bentley (Department for Communities and Local Government) **To:** Ms Dawett (E-Nik Ltd) 

**Date:** 15 May 2009 

**Subject:** RE: Clarification regarding Consultancy Services Contract

Dear Ms Dawett,

Regarding your query: Yes the 500 days would be purchased at a minimum per year to secure enik’s engagement for work.

Sincerely,

Mr Bentley Department for Communities and Local Government

