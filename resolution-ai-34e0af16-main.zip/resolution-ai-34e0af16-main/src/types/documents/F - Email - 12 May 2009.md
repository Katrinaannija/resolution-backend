**From:** Ms Dawett (E-Nik Ltd) 

**To:** Mr Bentley (Department for Communities and Local Government) 

**Date:** 12 May 2009 

**Subject:** Clarification regarding Consultancy Services Contract

Dear Mr Bentley,

Following our recent discussions, please could you confirm that the minimum 500 days will be purchased per year for the duration of the contract.

Kind regards,

Ms Dawett E-Nik Ltd

