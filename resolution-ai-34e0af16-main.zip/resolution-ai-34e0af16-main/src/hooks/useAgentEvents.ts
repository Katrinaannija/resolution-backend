import { useCallback, useEffect, useMemo, useState } from "react";
import rawEvents from "@/types/example.json";
import { AgentEvent } from "@/types/agent_event_types";

type AgentEventSource = "demo" | "live";

interface UseAgentEventsOptions {
  endpoint?: string;
  storageKey?: string;
  pollIntervalMs?: number;
}

interface UseAgentEventsResult {
  events: AgentEvent[];
  isLoading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
}

const DEFAULT_EVENTS_ENDPOINT =
  "https://resolution-ai-5ebd59013f295b9e988b6f3635c644a9.eu.langgraph.app/events";

const LIVE_EVENTS_ENDPOINT =
  import.meta.env.VITE_LIVE_EVENTS_ENDPOINT ?? DEFAULT_EVENTS_ENDPOINT;
const LIVE_EVENTS_STORAGE_KEY = "resolution-live-agent-events";
const LIVE_EVENTS_POLL_INTERVAL = 5000;

const demoEvents = rawEvents as AgentEvent[];

export const useAgentEvents = (
  source: AgentEventSource,
  options?: UseAgentEventsOptions,
): UseAgentEventsResult => {
  const { endpoint, storageKey, pollIntervalMs } = useMemo(
    () => ({
      endpoint: options?.endpoint ?? LIVE_EVENTS_ENDPOINT,
      storageKey: options?.storageKey ?? LIVE_EVENTS_STORAGE_KEY,
      pollIntervalMs: options?.pollIntervalMs ?? LIVE_EVENTS_POLL_INTERVAL,
    }),
    [options?.endpoint, options?.pollIntervalMs, options?.storageKey],
  );

  const [events, setEvents] = useState<AgentEvent[]>(
    source === "demo" ? demoEvents : [],
  );
  const [isLoading, setIsLoading] = useState(source === "live");
  const [error, setError] = useState<string | null>(null);

  const fetchEvents = useCallback(async () => {
    if (source !== "live") return;
    if (typeof window === "undefined") return;

    try {
      setIsLoading(true);
      const response = await fetch(endpoint, { cache: "no-store" });
      if (!response.ok) {
        throw new Error(`Failed to fetch live events (${response.status})`);
      }

      const payload = await response.json();
      if (!Array.isArray(payload)) {
        throw new Error("Live endpoint must return an array of agent events");
      }

      setEvents(payload as AgentEvent[]);
      window.localStorage.setItem(storageKey, JSON.stringify(payload));
      setError(null);
    } catch (err) {
      console.error("Failed to refresh live events", err);
      setError(err instanceof Error ? err.message : "Unknown error");
    } finally {
      setIsLoading(false);
    }
  }, [endpoint, source, storageKey]);

  useEffect(() => {
    if (source !== "live") return;
    if (typeof window === "undefined") return;

    const cached = window.localStorage.getItem(storageKey);
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) {
          setEvents(parsed as AgentEvent[]);
        }
      } catch (err) {
        console.warn("Failed to parse cached live events", err);
      }
    }

    fetchEvents();
    const intervalId = window.setInterval(fetchEvents, pollIntervalMs);
    return () => window.clearInterval(intervalId);
  }, [fetchEvents, pollIntervalMs, source, storageKey]);

  const refresh = useCallback(async () => {
    if (source !== "live") return;
    await fetchEvents();
  }, [fetchEvents, source]);

  return {
    events,
    isLoading,
    error,
    refresh,
  };
};

