import { useCallback, useEffect, useMemo, useRef, useState } from "react";

export type AgentStatus =
  | "idle"
  | "running"
  | "completed"
  | "failed"
  | "stopped";

interface UseAgentControllerOptions {
  baseUrl?: string;
  pollIntervalMs?: number;
}

interface UseAgentControllerResult {
  status: AgentStatus;
  agentError: string | null;
  agentMessage: string | null;
  agentPid: number | null;
  transportError: string | null;
  lastUpdated: number | null;
  isFetching: boolean;
  isActionPending: boolean;
  refreshStatus: () => Promise<void>;
  startAgent: () => Promise<void>;
  stopAgent: () => Promise<void>;
}

const DEFAULT_POLL_INTERVAL = 5000;
const normalizeBase = (value: string) => value.replace(/\/$/, "");
const DEFAULT_AGENT_BASE =
  "https://resolution-ai-5ebd59013f295b9e988b6f3635c644a9.eu.langgraph.app";
const DEFAULT_BASE_URL = normalizeBase(
  import.meta.env.VITE_LIVE_AGENT_BASE_URL ?? DEFAULT_AGENT_BASE,
);

export const useAgentController = (
  options?: UseAgentControllerOptions,
): UseAgentControllerResult => {
  const pollInterval = options?.pollIntervalMs ?? DEFAULT_POLL_INTERVAL;
  const baseUrl = useMemo(
    () => normalizeBase(options?.baseUrl ?? DEFAULT_BASE_URL),
    [options?.baseUrl],
  );

  const buildUrl = useCallback(
    (path: string) => `${baseUrl}${path}`,
    [baseUrl],
  );

  const [status, setStatus] = useState<AgentStatus>("idle");
  const [agentError, setAgentError] = useState<string | null>(null);
  const [agentMessage, setAgentMessage] = useState<string | null>(null);
  const [agentPid, setAgentPid] = useState<number | null>(null);
  const [transportError, setTransportError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<number | null>(null);
  const [isFetching, setIsFetching] = useState(false);
  const [isActionPending, setIsActionPending] = useState(false);
  const statusRef = useRef<AgentStatus>(status);
  const actionPendingRef = useRef(false);

  useEffect(() => {
    statusRef.current = status;
  }, [status]);

  useEffect(() => {
    actionPendingRef.current = isActionPending;
  }, [isActionPending]);

  const refreshStatus = useCallback(async () => {
    setIsFetching(true);
    try {
      const response = await fetch(buildUrl("/agent/status"), {
        cache: "no-store",
      });
      if (!response.ok) {
        throw new Error(`Failed to fetch status (${response.status})`);
      }
      const payload = await response.json();
      setStatus(payload.status ?? "idle");
      setAgentError(payload.error ?? null);
      setAgentMessage(payload.message ?? null);
      setAgentPid(typeof payload.pid === "number" ? payload.pid : null);
      setTransportError(null);
      setLastUpdated(Date.now());
    } catch (err) {
      setTransportError(
        err instanceof Error ? err.message : "Unknown controller error",
      );
    } finally {
      setIsFetching(false);
    }
  }, [buildUrl]);

  const startAgent = useCallback(async () => {
    if (statusRef.current === "running" || actionPendingRef.current) {
      return;
    }
    actionPendingRef.current = true;
    setIsActionPending(true);
    try {
      const response = await fetch(buildUrl("/agent/start"), {
        method: "POST",
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(payload?.detail ?? "Failed to start agent");
      }
      setAgentMessage(payload?.message ?? null);
      setAgentPid(
        typeof payload?.pid === "number" ? (payload.pid as number) : null,
      );
      setTransportError(null);
      setStatus(payload?.status ?? "running");
      await refreshStatus();
    } catch (err) {
      setTransportError(
        err instanceof Error ? err.message : "Unable to start agent",
      );
    } finally {
      actionPendingRef.current = false;
      setIsActionPending(false);
    }
  }, [buildUrl, refreshStatus]);

  const stopAgent = useCallback(async () => {
    if (statusRef.current !== "running" || actionPendingRef.current) {
      return;
    }
    actionPendingRef.current = true;
    setIsActionPending(true);
    try {
      const response = await fetch(buildUrl("/agent/stop"), {
        method: "POST",
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(payload?.detail ?? "Failed to stop agent");
      }
      setAgentMessage(payload?.message ?? null);
      setAgentPid(
        typeof payload?.pid === "number" ? (payload.pid as number) : null,
      );
      setTransportError(null);
      setStatus(payload?.status ?? "stopped");
      await refreshStatus();
    } catch (err) {
      setTransportError(
        err instanceof Error ? err.message : "Unable to stop agent",
      );
    } finally {
      actionPendingRef.current = false;
      setIsActionPending(false);
    }
  }, [buildUrl, refreshStatus]);

  useEffect(() => {
    if (typeof window === "undefined") return;
    refreshStatus();
    const intervalId = window.setInterval(refreshStatus, pollInterval);
    return () => window.clearInterval(intervalId);
  }, [pollInterval, refreshStatus]);

  return {
    status,
    agentError,
    transportError,
    agentMessage,
    agentPid,
    lastUpdated,
    isFetching,
    isActionPending,
    refreshStatus,
    startAgent,
    stopAgent,
  };
};

