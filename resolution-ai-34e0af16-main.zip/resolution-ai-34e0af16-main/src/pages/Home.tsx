import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { NeuralBackground } from "@/components/NeuralBackground";
import { useNavigate } from "react-router-dom";
import { Scale, Sparkles, FileText } from "lucide-react";

const Home = () => {
  const navigate = useNavigate();

  return (
    <div className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden">
      <NeuralBackground />
      
      <div className="relative z-10 max-w-6xl mx-auto px-grid text-center space-y-16">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: [0.65, 0, 0.35, 1] }}
          className="space-y-8"
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="inline-flex items-center gap-3 px-6 py-3 rounded-sm border border-quantum-ice/30 bg-card/50 backdrop-blur-sm"
          >
            <Scale className="w-5 h-5 text-quantum-ice" />
            <span className="text-sm font-mono text-quantum-ice tracking-wider">AUTOMATED ARBITRATION</span>
          </motion.div>

          <h1 className="text-7xl md:text-8xl font-display font-bold tracking-widest leading-tight">
            <span className="text-gradient-quantum">RESOLUTION</span>
            <br />
            <span className="text-plasma-white">AI</span>
          </h1>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed"
          >
            The judgment engine of the future. Resolve legal disputes in minutes instead of years using AI
          </motion.p>
        </motion.div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <Button
            size="lg"
            onClick={() => navigate("/submit")}
            className="group relative px-12 py-8 text-lg font-display tracking-widest bg-transparent border-2 border-quantum-ice text-quantum-ice hover:bg-quantum-ice hover:text-obsidian transition-all duration-300 hover-quantum"
          >
            <Sparkles className="w-5 h-5 mr-3 group-hover:rotate-12 transition-transform" />
            START ARBITRATION
          </Button>
        </motion.div>

        {/* Feature Grid */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="grid md:grid-cols-3 gap-8 pt-24"
        >
          {[
            {
              icon: FileText,
              title: "Case-file Analysis",
              description: "Submit documents from both parties. AI extracts key clauses and facts.",
            },
            {
              icon: Scale,
              title: "Synthetic Judgment",
              description: "AI reasons and drafts a judgment using contract clauses, laws, and legal precedents.",
            },
            {
              icon: Sparkles,
              title: "Total Transparency",
              description: "See how the AI weighed evidence, principles, and precedent.",
            },
          ].map((feature, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 1 + i * 0.1 }}
              className="group p-8 rounded-sm border border-border bg-card/30 backdrop-blur-sm hover:border-quantum-ice/50 transition-all duration-300 hover-quantum"
            >
              <feature.icon className="w-10 h-10 text-quantum-ice mb-6 group-hover:scale-110 transition-transform" />
              <h3 className="text-xl font-display mb-3 text-plasma-white">{feature.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
            </motion.div>
          ))}
        </motion.div>

        {/* Ambient Quote */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1.5 }}
          className="pt-16 text-center"
        >
          <p className="text-sm font-mono text-quantum-ice/60 tracking-wider italic">
            "Clear reasoning. Cited precedents. Faster and cheaper resolution."
          </p>
        </motion.div>
      </div>
    </div>
  );
};

export default Home;
