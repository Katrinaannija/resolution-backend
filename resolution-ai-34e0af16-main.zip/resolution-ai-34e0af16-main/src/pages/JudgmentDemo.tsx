import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import {
  AgentEvent,
  IssueWorkState,
  JudgementEvent,
  WorkflowSnapshot,
} from "@/types/agent_event_types";
import { ArrowLeft, Sparkles } from "lucide-react";
import { useAgentEvents } from "@/hooks/useAgentEvents";

const getNarratives = (event: JudgementEvent | undefined) => {
  if (!event?.judgement) return [];

  const { judgement, statement_of_claim, statement_of_defence } = event.judgement;
  return [
    { id: "judgement", label: "Final Judgment", body: judgement },
    { id: "statement_of_claim", label: "Statement of Claim", body: statement_of_claim },
    { id: "statement_of_defence", label: "Statement of Defence", body: statement_of_defence },
  ].filter((item) => !!item.body);
};

const formatIssueTitle = (issue: IssueWorkState, index: number) =>
  issue.issue?.legal_issue || issue.issue?.legal_issue || `Issue ${index + 1}`;

const getSnapshotLabel = (snapshot: WorkflowSnapshot, fallbackIndex: number) => {
  const base = snapshot.name ?? "Iteration";
  return `${base} #${fallbackIndex + 1}`;
};

type JudgmentViewProps = {
  events: AgentEvent[];
  mode: "demo" | "live";
  error?: string | null;
  onRetry?: () => Promise<void>;
};

function JudgmentView({ events, mode, error, onRetry }: JudgmentViewProps) {
  const navigate = useNavigate();

  const judgementEvent = useMemo(
    () => events.find((event): event is JudgementEvent => event.type === "judgement"),
    [events],
  );

  const issues = judgementEvent?.judgement?.issues ?? [];
  const narratives = useMemo(() => getNarratives(judgementEvent), [judgementEvent]);
  const [activeNarrative, setActiveNarrative] = useState<string>("judgement");

  useEffect(() => {
    if (!narratives.length) {
      setActiveNarrative("judgement");
      return;
    }

    if (!narratives.some((item) => item.id === activeNarrative)) {
      setActiveNarrative(narratives[0].id);
    }
  }, [narratives, activeNarrative]);

  const activeBody = narratives.find((item) => item.id === activeNarrative)?.body ?? "";

  const mergedSnapshots = (issue: IssueWorkState) => {
    const runs = [
      ...(issue.case_law_runs ?? []),
      ...(issue.document_runs ?? []),
    ];
    return runs;
  };

  const processingPath = mode === "live" ? "/live/processing" : "/processing";

  return (
    <div className="min-h-screen bg-obsidian text-plasma-white">
      <div className="mx-auto flex max-w-6xl flex-col gap-10 px-6 py-12">
        <header className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <p className="text-xs uppercase tracking-[0.45em] text-plasma-white/60">
              Tribunal Output
            </p>
            <h1 className="mt-2 text-4xl font-semibold text-plasma-white">
              Final Judgment & Orders
            </h1>
            <p className="mt-2 text-sm text-plasma-white/60">
              Complete write-up of the tribunal&apos;s reasoning, drafted with the same aesthetic
              system used during processing.
            </p>
          </div>
          <Button
            variant="outline"
            onClick={() => navigate(processingPath)}
            className="border-plasma-white/20 text-plasma-white hover:bg-plasma-white/10 self-start"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Processing
          </Button>
        </header>

        {mode === "live" && error && (
          <div className="rounded-xl border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm text-red-100">
            <p>Unable to fetch the live judgment: {error}</p>
            {onRetry && (
              <Button
                variant="outline"
                size="sm"
                className="mt-3 border-red-500/40 text-red-100 hover:bg-red-500/10"
                onClick={() => onRetry()}
              >
                Retry now
              </Button>
            )}
          </div>
        )}

        {judgementEvent ? (
          <>
            <Card className="border border-plasma-white/10 bg-plasma-white/5 text-plasma-white">
              <CardHeader className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2 text-2xl text-plasma-white">
                    <Sparkles className="h-5 w-5 text-quantum-ice" />
                    Tribunal Narrative
                  </CardTitle>
                  <p className="text-sm text-plasma-white/60">
                    Issued {new Date(judgementEvent.date).toLocaleString()}
                  </p>
                </div>
                <div className="flex flex-wrap gap-2">
                  {narratives.map((narrative) => (
                    <Button
                      key={narrative.id}
                      variant={activeNarrative === narrative.id ? "default" : "outline"}
                      size="sm"
                      className={cn(
                        activeNarrative === narrative.id
                          ? "bg-quantum-ice text-obsidian"
                          : "border-plasma-white/20 text-plasma-white hover:bg-plasma-white/10",
                      )}
                      onClick={() => setActiveNarrative(narrative.id)}
                    >
                      {narrative.label}
                    </Button>
                  ))}
                </div>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[65vh] min-h-[320px] rounded-xl border border-plasma-white/10 bg-obsidian/70 p-6">
                  <article className="space-y-4 whitespace-pre-wrap text-sm leading-relaxed text-plasma-white/90">
                    {activeBody}
                  </article>
                </ScrollArea>
              </CardContent>
            </Card>

            {/* Issue Synopsis removed per request */}

            {/* Issue-by-issue section removed per request */}
          </>
        ) : (
          <Card className="border border-plasma-white/10 bg-plasma-white/5 text-center text-plasma-white/80">
            <CardHeader>
              <CardTitle>No judgment available yet</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm">
                {mode === "live"
                  ? "We haven’t received a live judgment from the endpoint yet. Keep this tab open and we’ll keep polling automatically."
                  : "The processing pipeline has not produced a final judgment. Return to processing to monitor progress or upload new materials."}
              </p>
              <Button onClick={() => navigate(processingPath)} className="bg-quantum-ice text-obsidian">
                Go to Processing
              </Button>
            </CardContent>
          </Card>
        )}
        </div>
    </div>
  );
}

const JudgmentDemo = () => {
  const { events } = useAgentEvents("demo");
  return <JudgmentView events={events} mode="demo" />;
};

export const LiveJudgmentScreen = () => {
  const { events, error, refresh } = useAgentEvents("live");
  return (
    <JudgmentView
      events={events}
      mode="live"
      error={error}
      onRetry={refresh}
    />
  );
};

export default JudgmentDemo;
