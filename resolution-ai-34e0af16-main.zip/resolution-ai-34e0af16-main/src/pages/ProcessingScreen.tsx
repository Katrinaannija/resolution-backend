import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { AgentEvent, CaseLawEvent, DocumentEvent, JudgementEvent } from "@/types/agent_event_types";
import { cn } from "@/lib/utils";
import { useAgentEvents } from "@/hooks/useAgentEvents";
import { useAgentController, type AgentStatus } from "@/hooks/useAgentController";
import {
  CalendarClock,
  CheckCircle2,
  ChevronRight,
  Flame,
  Play,
  RefreshCw,
  Sparkles,
  Square,
} from "lucide-react";

type PipelineEvent = CaseLawEvent | DocumentEvent;

type IssueTimeline = {
  issueId: number | null;
  legalIssue: string;
  events: PipelineEvent[];
};

type ViewState = Record<string, number>;
type ToggleState = Record<string, boolean>;

const getIssueKey = (issueId: number | null) => (issueId === null ? "general" : issueId.toString());

const formatDateTime = (value: string) => {
  const date = new Date(value);
  return date.toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
};

const getEventLabel = (event?: AgentEvent) => {
  if (!event) return "Pending";
  if (event.type === "judgement") return "Judgement";
  const prefix = event.type === "case_law" ? "Case law" : "Documents";
  return `${prefix} v${event.iteration ?? "?"}`;
};

const isPipelineEvent = (event: AgentEvent): event is PipelineEvent =>
  event.type === "case_law" || event.type === "document";

type ProcessingViewProps = {
  events: AgentEvent[];
  mode: "demo" | "live";
  error?: string | null;
  onRetry?: () => Promise<void>;
  beforeIssues?: ReactNode;
};

function ProcessingView({ events, mode, error, onRetry, beforeIssues }: ProcessingViewProps) {
  const navigate = useNavigate();

  const sortedEvents = useMemo(
    () =>
      [...events].sort(
        (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime(),
      ),
    [events],
  );

  const issueTimelines = useMemo(() => {
    const map = new Map<string, IssueTimeline>();

    sortedEvents.forEach((event) => {
      if (!isPipelineEvent(event) || event.issue_id === null) return;
      const key = getIssueKey(event.issue_id);

      if (!map.has(key)) {
        map.set(key, {
          issueId: event.issue_id,
          legalIssue: event.legal_issue ?? `Issue ${event.issue_id ?? "?"}`,
          events: [],
        });
      }

      map.get(key)?.events.push(event);
    });

    return Array.from(map.values());
  }, [sortedEvents]);

  const issueDictionary = useMemo(() => {
    const dict: Record<string, IssueTimeline> = {};
    issueTimelines.forEach((issue) => {
      dict[getIssueKey(issue.issueId)] = issue;
    });
    return dict;
  }, [issueTimelines]);

  const [selectedEntries, setSelectedEntries] = useState<ViewState>({});
  const [showSuggestions, setShowSuggestions] = useState<ToggleState>({});
  const [activeIssueKey, setActiveIssueKey] = useState<string | null>(null);

  useEffect(() => {
    setSelectedEntries((prev) => {
      const next: ViewState = { ...prev };
      let changed = false;
      const availableKeys = new Set<string>();

      issueTimelines.forEach((issue) => {
        const key = getIssueKey(issue.issueId);
        availableKeys.add(key);
        const latestIndex = issue.events.length > 0 ? issue.events.length - 1 : 0;

        if (!(key in next)) {
          next[key] = latestIndex;
          changed = true;
        } else if (next[key] > latestIndex) {
          next[key] = latestIndex;
          changed = true;
        }
      });

      Object.keys(next).forEach((key) => {
        if (!availableKeys.has(key)) {
          delete next[key];
          changed = true;
        }
      });

      return changed ? next : prev;
    });
  }, [issueTimelines]);

  useEffect(() => {
    setShowSuggestions((prev) => {
      const next: ToggleState = { ...prev };
      let changed = false;
      const availableKeys = new Set<string>();

      issueTimelines.forEach((issue) => {
        const key = getIssueKey(issue.issueId);
        availableKeys.add(key);
        if (!(key in next)) {
          next[key] = false;
          changed = true;
        }
      });

      Object.keys(next).forEach((key) => {
        if (!availableKeys.has(key)) {
          delete next[key];
          changed = true;
        }
      });

      return changed ? next : prev;
    });
  }, [issueTimelines]);

  useEffect(() => {
    if (!issueTimelines.length) {
      if (activeIssueKey !== null) {
        setActiveIssueKey(null);
      }
      return;
    }

    const availableKeys = issueTimelines.map((issue) => getIssueKey(issue.issueId));

    if (!activeIssueKey || !availableKeys.includes(activeIssueKey)) {
      setActiveIssueKey(availableKeys[0]);
    }
  }, [issueTimelines, activeIssueKey]);

  const judgementEvent = sortedEvents.find(
    (event): event is JudgementEvent => event.type === "judgement",
  );

  const issueRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const judgementRef = useRef<HTMLDivElement | null>(null);
  const pendingIssueKey = useRef<string | null>(null);
  const decisionPath = mode === "live" ? "/live/judgement" : "/judgment";

  const handleSelectEntry = (issueKey: string, index: number, options?: { focus?: boolean }) => {
    setSelectedEntries((prev) => ({ ...prev, [issueKey]: index }));
    if (options?.focus === false) return;
    setActiveIssueKey(issueKey);
  };

  const handleToggleSuggestion = (issueKey: string, checked: boolean) => {
    setShowSuggestions((prev) => ({ ...prev, [issueKey]: checked }));
  };

  const getSelectedEvent = (issue: IssueTimeline): PipelineEvent | undefined => {
    const issueKey = getIssueKey(issue.issueId);
    const index = selectedEntries[issueKey] ?? issue.events.length - 1;
    return issue.events[index] ?? issue.events[0];
  };

  const scrollToIssue = (issueKey: string) => {
    const node = issueRefs.current[issueKey];
    if (node) {
      pendingIssueKey.current = issueKey;
      node.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  const handleSideEventClick = (event: AgentEvent) => {
    if (isPipelineEvent(event) && event.issue_id !== null) {
      const issueKey = getIssueKey(event.issue_id);
      const issue = issueDictionary[issueKey];
      if (!issue) return;
      const index = issue.events.findIndex(
        (entry) =>
          entry.date === event.date &&
          entry.type === event.type &&
          entry.iteration === event.iteration,
      );
      if (index >= 0) {
        handleSelectEntry(issueKey, index);
        scrollToIssue(issueKey);
      }
    } else if (event.type === "judgement") {
      setActiveIssueKey(null);
      navigate(decisionPath);
    }
  };

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (pendingIssueKey.current) {
          const pendingEntry = entries.find(
            (entry) => entry.isIntersecting && entry.target instanceof HTMLElement && entry.target.dataset.issueKey === pendingIssueKey.current,
          );
          if (pendingEntry) {
            pendingIssueKey.current = null;
          } else {
            return;
          }
        }

        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio);
        if (visible.length > 0) {
          const nextKey = (visible[0].target as HTMLElement).dataset.issueKey;
          if (nextKey) {
            setActiveIssueKey((prev) => (prev === nextKey ? prev : nextKey));
          }
        }
      },
      { threshold: 0.45 },
    );

    Object.values(issueRefs.current).forEach((node) => {
      if (node) observer.observe(node);
    });

    return () => observer.disconnect();
  }, [issueTimelines]);

  return (
    <div className="flex h-screen bg-obsidian text-plasma-white">
      <aside className="hidden w-full max-w-md border-r border-plasma-white/10 bg-obsidian/80 p-8 lg:flex lg:flex-col">
        <div className="mb-6">
          <p className="text-sm uppercase tracking-[0.3em] text-plasma-white/60">
            Live Stream
          </p>
          <h2 className="mt-2 text-2xl font-semibold text-plasma-white">
            Incoming Agent Events
          </h2>
          <p className="mt-1 text-sm text-plasma-white/60">
            Ordered exactly as they arrived in the pipeline.
          </p>
        </div>

        <ScrollArea className="h-full pr-4">
          <div className="space-y-3 pb-20">
            {sortedEvents.map((event, idx) => {
              const issueKey = isPipelineEvent(event) ? getIssueKey(event.issue_id) : "general";
              const issue = issueDictionary[issueKey];
              const selected = issue ? getSelectedEvent(issue) : undefined;
              const isActive =
                !!selected &&
                activeIssueKey === issueKey &&
                selected.date === event.date &&
                selected.type === event.type &&
                isPipelineEvent(event) &&
                selected.iteration === event.iteration;

              return (
              <motion.div
                  key={`${event.type}-${idx}-${event.date}`}
                  initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.02 }}
                  className={cn(
                    "rounded-xl border border-plasma-white/10 bg-plasma-white/5 p-4 transition hover:border-quantum-ice/60 hover:bg-plasma-white/10",
                    isActive && "border-quantum-ice/60 bg-quantum-ice/10 shadow-lg shadow-quantum-ice/10",
                    "cursor-pointer",
                  )}
                  onClick={() => handleSideEventClick(event)}
                >
                  <div className="flex items-center justify-between gap-2">
                    <Badge variant="outline" className="border-plasma-white/30 text-xs uppercase tracking-wide text-plasma-white">
                      {event.type === "judgement" ? "Judgement" : event.type}
                    </Badge>
                    <div className="flex items-center text-xs text-plasma-white/60">
                      <CalendarClock className="mr-1 h-4 w-4" />
                      {formatDateTime(event.date)}
                </div>
                  </div>
                  {isPipelineEvent(event) && event.legal_issue && (
                    <p className="mt-2 line-clamp-2 text-sm font-semibold text-plasma-white">
                      {event.legal_issue}
                    </p>
                  )}
                  {isPipelineEvent(event) && event.recommendation && (
                    <p className="mt-2 line-clamp-3 text-xs text-plasma-white/70">
                      {event.recommendation}
                    </p>
                  )}
                  {isPipelineEvent(event) && event.iteration != null && (
                    <p className="mt-3 text-xs uppercase tracking-wide text-quantum-ice">
                      {getEventLabel(event)}
                    </p>
                  )}
              </motion.div>
              );
            })}
        </div>
        </ScrollArea>
      </aside>

      <main className="flex-1 overflow-y-auto px-6 py-10 sm:px-10">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <p className="text-sm uppercase tracking-[0.4em] text-plasma-white/60">
              Processing
            </p>
            <h1 className="mt-2 text-3xl font-semibold text-plasma-white">
              Legal Issues in Flight
            </h1>
            <p className="mt-1 max-w-2xl text-sm text-plasma-white/60">
              Every card below represents a disputed legal issue. Use the version breadcrumbs to jump
              between iterations and inspect the recommendation or the follow-up suggestion that was
              generated at that moment in time.
            </p>
          </div>
          <div className="flex flex-col gap-3 sm:flex-row">
            {mode === "demo" && (
              <Button
                size="lg"
                className="relative overflow-hidden border border-orange-400/60 bg-gradient-to-r from-orange-500 via-red-500 to-yellow-400 text-white shadow-[0_0_30px_rgba(249,115,22,0.55)] transition hover:scale-105 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-orange-300"
                onClick={() => navigate("/live/processing")}
              >
                <span
                  aria-hidden="true"
                  className="absolute inset-0 bg-[radial-gradient(circle_at_top,rgba(255,255,255,0.35),transparent_60%)] opacity-70 mix-blend-screen"
                />
                <span className="relative flex items-center gap-2 font-semibold uppercase tracking-widest">
                  <Flame className="h-5 w-5 drop-shadow-[0_0_8px_rgba(255,255,255,0.85)]" />
                  RUN LIVE!
                  <Flame className="h-5 w-5 drop-shadow-[0_0_8px_rgba(255,255,255,0.85)]" />
                </span>
              </Button>
            )}
            <Button
              variant="ghost"
              size="lg"
              className="border border-plasma-white/10 bg-transparent text-plasma-white hover:bg-plasma-white/10"
              onClick={() => navigate("/documents")}
            >
              Inspect Source Docs
            </Button>
            <Button
              size="lg"
              className="bg-gradient-to-r from-quantum-ice to-verdict-mint text-obsidian"
              onClick={() => navigate(decisionPath)}
              disabled={mode === "live" && !judgementEvent}
            >
              View the Decision
            </Button>
          </div>
        </div>

        {mode === "live" && error && (
          <div className="mt-4 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-100">
            <p>Unable to sync the live feed: {error}</p>
            {onRetry && (
              <Button
                variant="outline"
                size="sm"
                className="mt-3 border-red-500/40 text-red-100 hover:bg-red-500/10"
                onClick={() => onRetry()}
              >
                Retry now
              </Button>
            )}
          </div>
        )}

        {beforeIssues}

        <div className="mt-10 space-y-8 pb-12">
          {issueTimelines.map((issue) => {
            const issueKey = getIssueKey(issue.issueId);
            const selectedEvent = getSelectedEvent(issue);
            const showSuggestion = showSuggestions[issueKey] ?? false;
            const displayText =
              (showSuggestion ? selectedEvent?.suggestion : selectedEvent?.recommendation) ||
              "No content provided for this entry.";
            
            return (
              <Card
                key={issueKey}
                data-issue-key={issueKey}
                ref={(node) => {
                  issueRefs.current[issueKey] = node;
                }}
                className="border border-plasma-white/10 bg-plasma-white/5 text-plasma-white shadow-2xl shadow-obsidian/30"
              >
                <CardHeader className="space-y-3">
                  <div className="flex flex-wrap items-center gap-3">
                    <CardTitle className="text-xl text-plasma-white">
                      {issue.legalIssue}
                    </CardTitle>
                    {selectedEvent?.solved && (
                      <Badge className="bg-verdict-mint/20 text-verdict-mint">
                        <CheckCircle2 className="mr-1 h-4 w-4" />
                        Solved
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-plasma-white/60">
                    {selectedEvent?.legal_issue || "Active analysis"}
                  </p>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex flex-wrap items-center justify-between gap-4">
                    <div className="flex flex-col text-sm text-plasma-white/70">
                      <span className="text-xs uppercase tracking-wide text-plasma-white/50">
                        Currently viewing
                      </span>
                      <span className="font-semibold text-plasma-white">
                        {getEventLabel(selectedEvent)}
                      </span>
                    </div>
                    <div className="flex items-center gap-3">
                      <Label htmlFor={`toggle-${issueKey}`} className="text-sm text-plasma-white/70">
                        Show suggestions
                      </Label>
                      <Switch
                        id={`toggle-${issueKey}`}
                        checked={showSuggestion}
                        onCheckedChange={(checked) => handleToggleSuggestion(issueKey, checked)}
                      />
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 text-sm font-medium">
                    {issue.events.map((event, index) => {
                      const isSelected = selectedEvent === event;
                      const isSolved = event.solved;

                      return (
                        <div key={`${issueKey}-${event.date}-${index}`} className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleSelectEntry(issueKey, index)}
                            className={cn(
                              "rounded-full border border-transparent px-4 py-1.5 text-xs uppercase tracking-wide transition",
                              isSelected
                                ? "bg-quantum-ice/20 text-quantum-ice"
                                : "bg-plasma-white/10 text-plasma-white/70 hover:bg-plasma-white/20",
                            )}
                          >
                            {isSolved ? "Solved" : getEventLabel(event)}
                          </button>
                          {index < issue.events.length - 1 && (
                            <ChevronRight className="h-4 w-4 text-plasma-white/30" />
                          )}
                        </div>
                      );
                    })}
                  </div>

                  <div className="whitespace-pre-line rounded-xl border border-plasma-white/10 bg-obsidian/70 p-6 text-sm leading-relaxed text-plasma-white/90">
                    {displayText}
                </div>
                </CardContent>
              </Card>
            );
          })}

          {judgementEvent && (
            <Card
              ref={judgementRef}
              className="border border-verdict-mint/30 bg-verdict-mint/5 text-plasma-white"
            >
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-verdict-mint">
                  <Sparkles className="h-5 w-5" />
                  Final Judgement Snapshot
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 text-sm leading-relaxed text-plasma-white/80">
                <p className="text-xs uppercase tracking-wide text-plasma-white/60">
                  Published {formatDateTime(judgementEvent.date)}
                </p>
                {judgementEvent.judgement?.issues_table && (
                  <div className="rounded-lg border border-plasma-white/10 bg-plasma-white/5 p-4">
                    <p className="text-xs uppercase tracking-wide text-plasma-white/50">Issues table</p>
                    <p className="mt-2 whitespace-pre-line text-sm text-plasma-white/80">
                      {judgementEvent.judgement.issues_table}
                    </p>
                  </div>
                )}
                {judgementEvent.judgement?.judgement && (
                  <div className="rounded-lg border border-plasma-white/10 bg-plasma-white/5 p-4">
                    <p className="text-xs uppercase tracking-wide text-plasma-white/50">Body</p>
                    <p className="mt-2 whitespace-pre-line text-sm text-plasma-white/80">
                      {judgementEvent.judgement.judgement}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>
        {mode === "live" && !issueTimelines.length && (
          <Card className="border border-plasma-white/10 bg-plasma-white/5 text-center text-plasma-white/80">
            <CardHeader>
              <CardTitle>No live issues yet</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <p>The live endpoint has not returned any issue events yet. We&apos;ll keep polling every few seconds.</p>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
}

export default function ProcessingScreen() {
  const { events } = useAgentEvents("demo");
  return <ProcessingView events={events} mode="demo" />;
}

export function LiveProcessingScreen() {
  const { events, error, refresh } = useAgentEvents("live");
  const controller = useAgentController();
  return (
    <ProcessingView
      events={events}
      mode="live"
      error={error}
      onRetry={refresh}
      beforeIssues={
        <LiveAgentControls
          status={controller.status}
          agentError={controller.agentError}
          agentMessage={controller.agentMessage}
          agentPid={controller.agentPid}
          transportError={controller.transportError}
          lastUpdated={controller.lastUpdated}
          isActionPending={controller.isActionPending}
          onStart={controller.startAgent}
          onStop={controller.stopAgent}
          onRefresh={controller.refreshStatus}
        />
      }
    />
  );
}

const statusCopy: Record<
  AgentStatus,
  { label: string; badgeClass: string; dotClass: string }
> = {
  idle: {
    label: "Idle",
    badgeClass: "bg-plasma-white/10 text-plasma-white",
    dotClass: "bg-plasma-white",
  },
  running: {
    label: "Running",
    badgeClass: "bg-quantum-ice/20 text-quantum-ice",
    dotClass: "bg-quantum-ice",
  },
  completed: {
    label: "Completed",
    badgeClass: "bg-verdict-mint/20 text-verdict-mint",
    dotClass: "bg-verdict-mint",
  },
  failed: {
    label: "Failed",
    badgeClass: "bg-red-500/20 text-red-300",
    dotClass: "bg-red-400",
  },
  stopped: {
    label: "Stopped",
    badgeClass: "bg-amber-500/20 text-amber-200",
    dotClass: "bg-amber-300",
  },
};

type LiveAgentControlsProps = {
  status: AgentStatus;
  agentError: string | null;
  agentMessage: string | null;
  agentPid: number | null;
  transportError: string | null;
  lastUpdated: number | null;
  isActionPending: boolean;
  onStart: () => Promise<void>;
  onStop: () => Promise<void>;
  onRefresh: () => Promise<void>;
};

function LiveAgentControls({
  status,
  agentError,
  agentMessage,
  agentPid,
  transportError,
  lastUpdated,
  isActionPending,
  onStart,
  onStop,
  onRefresh,
}: LiveAgentControlsProps) {
  const meta = statusCopy[status] ?? statusCopy.idle;
  const canStart = ["idle", "completed", "failed", "stopped"].includes(status);
  const canStop = status === "running";

  return (
    <div className="mt-8 rounded-2xl border border-plasma-white/10 bg-plasma-white/5 p-5 shadow-lg shadow-obsidian/40">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <p className="text-xs uppercase tracking-[0.35em] text-plasma-white/60">
            Orchestrator control
          </p>
          <div className="mt-2 flex items-center gap-3">
            <span
              className={cn(
                "inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs font-semibold",
                meta.badgeClass,
              )}
            >
              <span className={cn("h-2 w-2 rounded-full", meta.dotClass)} />
              {meta.label}
            </span>
          </div>
          {lastUpdated && (
            <p className="mt-1 text-xs text-plasma-white/60">
              Updated {new Date(lastUpdated).toLocaleTimeString()}
            </p>
          )}
          {agentError && (
            <p className="mt-2 text-xs text-amber-200">
              Agent reported: {agentError}
            </p>
          )}
          {agentMessage && (
            <p className="mt-2 text-xs text-plasma-white/70">
              Last action: {agentMessage}
              {agentPid != null && ` (pid ${agentPid})`}
            </p>
          )}
          {transportError && (
            <p className="mt-2 text-xs text-red-300">
              Controller error: {transportError}
            </p>
          )}
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            size="sm"
            onClick={onStart}
            disabled={!canStart || isActionPending}
            className="bg-quantum-ice/70 text-obsidian hover:bg-quantum-ice"
          >
            <Play className="mr-1 h-4 w-4" />
            Start run
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={onStop}
            disabled={!canStop || isActionPending}
            className="border-plasma-white/30 text-plasma-white hover:bg-plasma-white/10"
          >
            <Square className="mr-1 h-4 w-4" />
            Stop run
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={onRefresh}
            className="text-plasma-white hover:text-quantum-ice"
          >
            <RefreshCw className="mr-1 h-4 w-4" />
            Refresh
          </Button>
        </div>
      </div>
    </div>
  );
}

