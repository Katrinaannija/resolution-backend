import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Upload, X, FileText } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { demoDocuments } from "@/lib/demo-documents";

export default function Submit() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [files, setFiles] = useState<File[]>([]);
  const preloadedDocuments = demoDocuments;
  const statementOfClaimDoc = preloadedDocuments.find((doc) => doc.title.toLowerCase().includes("statement of claim"));
  const statementOfDefenceDoc = preloadedDocuments.find((doc) => doc.title.toLowerCase().includes("statement of defence"));
  const [claimantPosition, setClaimantPosition] = useState(statementOfClaimDoc?.content ?? "");
  const [defendantPosition, setDefendantPosition] = useState(statementOfDefenceDoc?.content ?? "");
  const [isDragging, setIsDragging] = useState(false);
  const totalAttachments = preloadedDocuments.length + files.length;

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const droppedFiles = Array.from(e.dataTransfer.files).filter(
      (file) =>
        file.type === "application/pdf" ||
        file.type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
        file.type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    );
    setFiles((prev) => [...prev, ...droppedFiles]);
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const selectedFiles = Array.from(e.target.files);
      setFiles((prev) => [...prev, ...selectedFiles]);
    }
  };

  const removeFile = (index: number) => {
    setFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const handleStartArbitration = () => {
    // Validate inputs
    if (totalAttachments === 0) {
      toast({
        title: "Files required",
        description: "Please upload or use the demo documents to proceed.",
        variant: "destructive",
      });
      return;
    }

    if (!claimantPosition.trim() || !defendantPosition.trim()) {
      toast({
        title: "Positions required",
        description: "Please provide both claimant and defendant positions.",
        variant: "destructive",
      });
      return;
    }

    // Store data and navigate to real processing
    // TODO: Send to backend API
    navigate("/processing");
  };

  return (
    <div className="min-h-screen bg-obsidian text-plasma-white">
      {/* Header */}
      <header className="border-b border-plasma-white/10 px-8 py-6">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <h1 className="text-2xl font-display tracking-widest">RESOLUTION AI</h1>
          <span className="text-sm font-mono text-quantum-ice tracking-wider">CASE SUBMISSION</span>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-5xl mx-auto px-8 py-12 space-y-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl font-display mb-2 tracking-wide">Submit case materials</h2>
          <p className="text-plasma-white/60">Upload documents and provide each party's position</p>
        </motion.div>

        {/* File Upload Area */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          onDrop={handleDrop}
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          className={`
            relative border-2 border-dashed rounded-lg p-12 text-center transition-all duration-300
            ${isDragging ? "border-quantum-ice bg-quantum-ice/5" : "border-plasma-white/20 hover:border-quantum-ice/50"}
          `}
        >
          <input
            type="file"
            id="file-upload"
            multiple
            accept=".pdf,.docx,.xlsx"
            onChange={handleFileInput}
            className="hidden"
          />
          <label htmlFor="file-upload" className="cursor-pointer">
            <Upload className="w-12 h-12 mx-auto mb-4 text-quantum-ice" />
            <p className="text-lg mb-2">Drop files here or click to upload</p>
            <p className="text-sm text-plasma-white/60">PDF, DOCX, XLSX supported</p>
            <p className="mt-2 text-xs uppercase tracking-wide text-quantum-ice">
              {preloadedDocuments.length} demo files already attached
            </p>
          </label>
        </motion.div>

        {/* Attachment inventory */}
        {(preloadedDocuments.length > 0 || files.length > 0) && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-3"
          >
            {preloadedDocuments.length > 0 && (
              <div className="space-y-2 rounded-xl border border-plasma-white/10 bg-plasma-white/5 p-4">
                <div className="flex items-center justify-between text-sm">
                  <p className="font-semibold text-plasma-white">Preloaded evidence</p>
                  <Badge variant="outline" className="border-quantum-ice/40 text-xs uppercase tracking-wide text-quantum-ice">
                    {preloadedDocuments.length} files
                  </Badge>
                </div>
                <div className="max-h-48 space-y-2 overflow-y-auto pr-2">
                  {preloadedDocuments.map((doc) => (
                    <div key={doc.id} className="flex items-center gap-3 rounded-lg border border-plasma-white/10 bg-obsidian/50 px-3 py-2 text-sm">
                      <FileText className="h-4 w-4 text-quantum-ice" />
                      <span className="flex-1 truncate">{doc.title}</span>
                      <span className="text-xs uppercase text-plasma-white/50">{doc.extension}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {files.length > 0 && (
              <div className="space-y-2 rounded-xl border border-plasma-white/10 bg-plasma-white/5 p-4">
                <div className="text-sm font-semibold text-plasma-white">Additional uploads</div>
                {files.map((file, index) => (
                  <div
                    key={`${file.name}-${index}`}
                    className="flex items-center justify-between rounded-lg border border-plasma-white/10 bg-obsidian/60 px-4 py-3"
                  >
                    <div className="flex items-center gap-3">
                      <FileText className="w-5 h-5 text-quantum-ice" />
                      <div>
                        <p className="text-sm font-medium">{file.name}</p>
                        <p className="text-xs text-plasma-white/60">
                          {(file.size / 1024).toFixed(2)} KB
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => removeFile(index)}
                      className="text-plasma-white/60 hover:text-warning-magenta transition-colors"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        )}

        {/* Claimant's Position */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="space-y-2"
        >
          <label htmlFor="claimant" className="block text-sm font-medium">
            Claimant's position
          </label>
          <Textarea
            id="claimant"
            value={claimantPosition}
            onChange={(e) => setClaimantPosition(e.target.value)}
            placeholder="Describe the claimant's claims and arguments..."
            className="min-h-[120px] bg-plasma-white/5 border-plasma-white/20 text-plasma-white placeholder:text-plasma-white/40 focus:border-quantum-ice"
          />
          {statementOfClaimDoc && (
            <p className="text-xs text-plasma-white/50">Auto-filled from {statementOfClaimDoc.title}</p>
          )}
        </motion.div>

        {/* Defendant's Position */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="space-y-2"
        >
          <label htmlFor="defendant" className="block text-sm font-medium">
            Defendant's position
          </label>
          <Textarea
            id="defendant"
            value={defendantPosition}
            onChange={(e) => setDefendantPosition(e.target.value)}
            placeholder="Describe the defendant's defences and arguments..."
            className="min-h-[120px] bg-plasma-white/5 border-plasma-white/20 text-plasma-white placeholder:text-plasma-white/40 focus:border-quantum-ice"
          />
          {statementOfDefenceDoc && (
            <p className="text-xs text-plasma-white/50">Auto-filled from {statementOfDefenceDoc.title}</p>
          )}
        </motion.div>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="flex items-center justify-end pt-8"
        >
          <Button
            onClick={handleStartArbitration}
            size="lg"
            className="px-12 bg-gradient-to-r from-quantum-ice to-verdict-mint text-obsidian font-bold hover:opacity-90 transition-opacity"
          >
            Start Arbitration
          </Button>
        </motion.div>
      </main>
    </div>
  );
}
