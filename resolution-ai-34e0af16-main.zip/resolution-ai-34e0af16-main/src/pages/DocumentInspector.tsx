import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Search, FileText, ArrowLeft } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { demoDocuments } from "@/lib/demo-documents";

export default function DocumentInspector() {
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const [activeDocId, setActiveDocId] = useState<string | null>(demoDocuments[0]?.id ?? null);

  const filteredDocs = useMemo(() => {
    const term = search.trim().toLowerCase();
    if (!term) return demoDocuments;

    return demoDocuments.filter(
      (doc) =>
        doc.title.toLowerCase().includes(term) ||
        doc.shortCode.toLowerCase().includes(term) ||
        doc.content.toLowerCase().includes(term),
    );
  }, [search]);

  useEffect(() => {
    if (!filteredDocs.length) {
      setActiveDocId(null);
      return;
    }
    if (!activeDocId || !filteredDocs.some((doc) => doc.id === activeDocId)) {
      setActiveDocId(filteredDocs[0].id);
    }
  }, [filteredDocs, activeDocId]);

  const activeDoc = useMemo(() => filteredDocs.find((doc) => doc.id === activeDocId) ?? null, [filteredDocs, activeDocId]);

  return (
    <div className="flex h-screen bg-obsidian text-plasma-white">
      <aside className="hidden w-full max-w-md border-r border-plasma-white/10 bg-obsidian/80 p-8 lg:flex lg:flex-col">
        <div className="mb-6">
          <p className="text-sm uppercase tracking-[0.3em] text-plasma-white/60">Document Stack</p>
          <h2 className="mt-2 text-2xl font-semibold text-plasma-white">Evidence Library</h2>
          <p className="mt-1 text-sm text-plasma-white/60">
            Browse every source document that fed the processing pipeline.
          </p>
        </div>

        <div className="mb-5">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-plasma-white/40" />
            <Input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search title or text..."
              className="border-plasma-white/10 bg-obsidian/50 pl-9 text-sm text-plasma-white placeholder:text-plasma-white/50"
            />
          </div>
          <p className="mt-2 text-xs text-plasma-white/50">
            {filteredDocs.length} of {demoDocuments.length} documents
          </p>
        </div>

        <div className="h-full overflow-y-auto pr-4">
          <div className="space-y-3 pb-20">
            {filteredDocs.map((doc, idx) => {
              const isActive = doc.id === activeDocId;
              return (
                <motion.button
                  key={doc.id}
                  type="button"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.015 }}
                  onClick={() => setActiveDocId(doc.id)}
                  className={cn(
                    "w-full rounded-xl border border-plasma-white/10 bg-plasma-white/5 p-4 text-left transition hover:border-quantum-ice/60 hover:bg-plasma-white/10",
                    isActive && "border-quantum-ice/60 bg-quantum-ice/10 shadow-lg shadow-quantum-ice/10",
                  )}
                >
                  <div className="flex items-center justify-between gap-2">
                    <Badge variant="outline" className="border-plasma-white/30 text-xs uppercase tracking-wide">
                      {doc.extension || "TEXT"}
                    </Badge>
                    <p className="text-xs text-plasma-white/60">{doc.shortCode}</p>
                  </div>
                  <p className="mt-2 truncate text-sm font-semibold text-plasma-white">{doc.title}</p>
                  <p className="mt-2 line-clamp-2 text-xs text-plasma-white/70">{doc.content.slice(0, 200)}</p>
                  <p className="mt-3 text-xs uppercase tracking-wide text-quantum-ice">{doc.wordCount} words</p>
                </motion.button>
              );
            })}
          </div>
        </div>
      </aside>

      <main className="flex-1 overflow-y-auto px-6 py-10 sm:px-10">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <p className="text-sm uppercase tracking-[0.4em] text-plasma-white/60">Document Inspector</p>
            <h1 className="mt-2 text-3xl font-semibold text-plasma-white">Source Materials</h1>
            <p className="mt-1 max-w-2xl text-sm text-plasma-white/60">
              Review the raw evidence, cross-reference versions, and spot the exact passages the agents
              consumed while drafting recommendations.
            </p>
          </div>
          <div className="flex flex-col gap-3 sm:flex-row">
            <Button
              variant="ghost"
              size="lg"
              className="border border-plasma-white/10 bg-transparent text-plasma-white hover:bg-plasma-white/10"
              onClick={() => navigate("/processing")}
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Processing
            </Button>
            <Button
              size="lg"
              className="bg-gradient-to-r from-quantum-ice to-verdict-mint text-obsidian"
              onClick={() => navigate("/judgment")}
            >
              View the Decision
            </Button>
          </div>
        </div>

        <div className="mt-10 space-y-8 pb-12">
          {!filteredDocs.length && (
            <Card className="border border-plasma-white/10 bg-plasma-white/5 text-plasma-white">
              <CardHeader>
                <CardTitle>No documents match your search.</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-plasma-white/70">
                Try another keyword or clear the filter to see the entire evidence library.
              </CardContent>
            </Card>
          )}

          {activeDoc && (
            <Card className="border border-plasma-white/10 bg-plasma-white/5 text-plasma-white shadow-2xl shadow-obsidian/30">
              <CardHeader className="space-y-3">
                <div className="flex flex-wrap items-center gap-3">
                  <FileText className="h-5 w-5 text-quantum-ice" />
                  <CardTitle className="text-2xl text-plasma-white">{activeDoc.title}</CardTitle>
                  <Badge className="bg-verdict-mint/20 text-verdict-mint">{activeDoc.shortCode}</Badge>
                </div>
                <p className="text-sm text-plasma-white/60">{activeDoc.path.replace("/src/", "")}</p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid gap-4 sm:grid-cols-3">
                  <div className="rounded-xl border border-plasma-white/10 bg-obsidian/60 p-4">
                    <p className="text-xs uppercase tracking-wide text-plasma-white/60">Words</p>
                    <p className="mt-2 text-2xl font-semibold text-plasma-white">
                      {activeDoc.wordCount.toLocaleString()}
                    </p>
                  </div>
                  <div className="rounded-xl border border-plasma-white/10 bg-obsidian/60 p-4">
                    <p className="text-xs uppercase tracking-wide text-plasma-white/60">Characters</p>
                    <p className="mt-2 text-2xl font-semibold text-plasma-white">
                      {activeDoc.charCount.toLocaleString()}
                    </p>
                  </div>
                  <div className="rounded-xl border border-plasma-white/10 bg-obsidian/60 p-4">
                    <p className="text-xs uppercase tracking-wide text-plasma-white/60">Format</p>
                    <p className="mt-2 text-2xl font-semibold text-plasma-white">
                      {activeDoc.extension || "TEXT"}
                    </p>
                  </div>
                </div>

                <div className="rounded-xl border border-plasma-white/10 bg-obsidian/70 p-0">
                  <div className="h-[60vh] overflow-y-auto rounded-xl">
                    <pre className="whitespace-pre-wrap px-6 py-6 font-mono text-sm leading-relaxed text-plasma-white/90">
                      {activeDoc.content}
                    </pre>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}


