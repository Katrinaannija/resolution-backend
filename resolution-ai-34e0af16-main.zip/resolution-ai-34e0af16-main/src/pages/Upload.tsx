import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { Upload as UploadIcon, FileText, CheckCircle2, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const Upload = () => {
  const [files, setFiles] = useState<File[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const droppedFiles = Array.from(e.dataTransfer.files);
    setFiles((prev) => [...prev, ...droppedFiles]);
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const selectedFiles = Array.from(e.target.files);
      setFiles((prev) => [...prev, ...selectedFiles]);
    }
  };

  const processDocuments = async () => {
    if (files.length === 0) {
      toast({
        title: "No documents uploaded",
        description: "Please upload at least one document to proceed.",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);

    // Simulate AI processing
    await new Promise((resolve) => setTimeout(resolve, 3000));

    toast({
      title: "Analysis complete",
      description: "Documents parsed. Generating judgment...",
    });

    setTimeout(() => {
      navigate("/judgment");
    }, 1000);
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="border-b border-border bg-card/30 backdrop-blur-sm">
        <div className="container mx-auto px-8 py-6 flex items-center justify-between">
          <button
            onClick={() => navigate("/")}
            className="text-2xl font-display tracking-widest text-quantum-ice hover:text-processing-ice transition-colors"
          >
            RESOLUTION AI
          </button>
          <div className="text-sm font-mono text-muted-foreground">DOCUMENT INTAKE</div>
        </div>
      </header>

      <div className="flex-1 container mx-auto px-8 py-16 max-w-5xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="space-y-12"
        >
          {/* Title */}
          <div className="text-center space-y-4">
            <h1 className="text-5xl font-display tracking-widest text-plasma-white">
              Submit Case Materials
            </h1>
            <p className="text-muted-foreground">
              Party statements, contracts, and supporting documents. AI will extract and analyze the relevant facts and legal issues.
            </p>
          </div>

          {/* Upload Zone */}
          <motion.div
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragging(true);
            }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={handleDrop}
            animate={{
              borderColor: isDragging
                ? "hsl(var(--quantum-ice))"
                : "hsl(var(--border))",
              backgroundColor: isDragging ? "hsl(var(--card))" : "transparent",
            }}
            className="relative border-2 border-dashed rounded-sm p-16 text-center transition-all duration-300"
          >
            <input
              type="file"
              multiple
              onChange={handleFileInput}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              accept=".pdf,.doc,.docx,.txt"
            />

            <motion.div
              animate={{
                scale: isDragging ? 1.05 : 1,
              }}
              className="space-y-6"
            >
              <UploadIcon className="w-16 h-16 text-quantum-ice mx-auto" />
              <div>
                <p className="text-lg font-display tracking-wider text-plasma-white mb-2">
                  DROP FILES OR CLICK TO UPLOAD
                </p>
                <p className="text-sm text-muted-foreground">
                  PDF, DOC, DOCX, TXT • Multiple files supported
                </p>
              </div>
            </motion.div>
          </motion.div>

          {/* File List */}
          <AnimatePresence>
            {files.length > 0 && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="space-y-4"
              >
                <h3 className="font-display tracking-wider text-quantum-ice">
                  UPLOADED DOCUMENTS ({files.length})
                </h3>
                <div className="space-y-3">
                  {files.map((file, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.1 }}
                      className="flex items-center gap-4 p-4 rounded-sm border border-border bg-card/50 backdrop-blur-sm"
                    >
                      <FileText className="w-5 h-5 text-quantum-ice" />
                      <div className="flex-1">
                        <p className="font-mono text-sm text-plasma-white">{file.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {(file.size / 1024).toFixed(2)} KB
                        </p>
                      </div>
                      <CheckCircle2 className="w-5 h-5 text-verdict-mint" />
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Processing State */}
          {isProcessing && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="p-8 rounded-sm border border-quantum-ice/50 bg-card/80 backdrop-blur-sm text-center space-y-4"
            >
              <Loader2 className="w-12 h-12 text-quantum-ice mx-auto animate-spin" />
              <p className="font-display tracking-wider text-processing-ice">
                ANALYZING CONTRACTUAL LOGIC...
              </p>
              <p className="text-sm font-mono text-muted-foreground">
                Parsing documents • Extracting issues • Applying precedent
              </p>
            </motion.div>
          )}

          {/* Action Button */}
          <div className="flex justify-center pt-8">
            <Button
              size="lg"
              onClick={processDocuments}
              disabled={files.length === 0 || isProcessing}
              className="px-12 py-6 text-base font-display tracking-widest bg-transparent border-2 border-quantum-ice text-quantum-ice hover:bg-quantum-ice hover:text-obsidian transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed hover-quantum"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-5 h-5 mr-3 animate-spin" />
                  PROCESSING
                </>
              ) : (
                <>Generate Arbitral Award</>
              )}
            </Button>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Upload;
