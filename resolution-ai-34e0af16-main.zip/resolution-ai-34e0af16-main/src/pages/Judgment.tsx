import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { FileDown, FileText } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface JudgmentSection {
  id: string;
  title: string;
}

interface JudgmentDocument {
  caseNumber: string;
  citation: string;
  date: string;
  claimant: string;
  defendant: string;
  content: string; // Full HTML judgment text
  sections: JudgmentSection[];
}

// Mock judgment with full UK High Court format
const mockJudgment: JudgmentDocument = {
  caseNumber: "CL-2024-000847",
  citation: "[2024] EWHC 847 (Comm)",
  date: "29 November 2025",
  claimant: "TechForward Solutions Ltd",
  defendant: "GlobalConsult Partners LLP",
  sections: [
    { id: "introduction", title: "Introduction" },
    { id: "background", title: "Background and Undisputed Facts" },
    { id: "contract", title: "The Contract and Relevant Provisions" },
    { id: "issues", title: "The Issues" },
    { id: "positions", title: "The Parties' Positions" },
    { id: "analysis", title: "Analysis and Determination" },
    { id: "conclusion", title: "Conclusion on Liability" },
    { id: "orders", title: "Relief and Orders" },
  ],
  content: `
    <div class="text-center mb-12 space-y-2">
      <div class="text-slate-400 font-mono text-sm">[2024] EWHC 847 (Comm)</div>
      <div class="text-slate-400 font-mono text-sm">Case No: CL-2024-000847</div>
      <div class="text-slate-400 font-mono text-sm">Date: 29 November 2025</div>
      <div class="text-quantum-ice font-display uppercase tracking-wider mt-6">Before:</div>
      <div class="text-plasma-white font-display uppercase tracking-wider">The Agentic Arbitral Tribunal</div>
      
      <div class="mt-8 space-y-1">
        <div class="text-slate-300">Between:</div>
        <div class="text-plasma-white font-semibold">TechForward Solutions Ltd</div>
        <div class="text-slate-400 italic">(Claimant)</div>
        <div class="text-slate-400 my-2">-and-</div>
        <div class="text-plasma-white font-semibold">GlobalConsult Partners LLP</div>
        <div class="text-slate-400 italic">(Defendant)</div>
      </div>
    </div>

    <div id="introduction">
      <h2>I. Introduction</h2>
      
      <p><span class="para-number">(1)</span>This is a claim arising from a consultancy services agreement dated 15 January 2023 (the "Agreement") between TechForward Solutions Ltd ("the Claimant") and GlobalConsult Partners LLP ("the Defendant"). The Claimant seeks damages for breach of contract and declaratory relief concerning the interpretation of certain provisions of the Agreement.</p>
      
      <p><span class="para-number">(2)</span>The Claimant's case is that the Defendant was contractually obliged to purchase a minimum of 500 consultancy days per year at the agreed rate of £850 per day, and that the Defendant repudiated this obligation by purporting to terminate the Agreement prematurely. The Claimant quantifies its loss at £212,500 representing 250 unpurchased days.</p>
      
      <p><span class="para-number">(3)</span>The Defendant disputes liability. It contends that the Agreement contained no minimum purchase obligation, and that in any event it was entitled to terminate the Agreement on notice in accordance with Clause 8.2 thereof.</p>
      
      <p><span class="para-number">(4)</span>In reaching my determination, I have considered the pleadings, witness statements from both parties, contemporaneous documentary evidence including email correspondence and meeting minutes, and written submissions on contractual construction and relevant case law.</p>
    </div>

    <div id="background">
      <h2>II. Background and Undisputed Facts</h2>
      
      <p><span class="para-number">(5)</span>The following facts are either admitted or clearly established by the documentary evidence and are not in dispute.</p>
      
      <p><span class="para-number">(6)</span>The Claimant is a technology consultancy firm specialising in digital transformation services. The Defendant is a management consultancy partnership operating in the financial services sector.</p>
      
      <p><span class="para-number">(7)</span>In late 2022, the parties entered into negotiations concerning the provision by the Claimant of technical consultancy services to support the Defendant's client engagements. These negotiations culminated in the execution of the Agreement on 15 January 2023.</p>
      
      <p><span class="para-number">(8)</span>Between January 2023 and March 2024, the Defendant purchased consultancy services totalling 285 days. The Claimant invoiced for these services at the contractual rate of £850 per day, and all invoices were paid without dispute.</p>
      
      <p><span class="para-number">(9)</span>On 15 March 2024, the Defendant gave notice purporting to terminate the Agreement with effect from 30 April 2024. The Claimant objected to this termination by letter dated 22 March 2024, asserting that the Defendant remained liable for the balance of the minimum annual commitment.</p>
    </div>

    <div id="contract">
      <h2>III. The Contract and Relevant Provisions</h2>
      
      <p><span class="para-number">(10)</span>The Agreement is a relatively short document running to eight clauses. The material provisions for present purposes are as follows.</p>
      
      <p><span class="para-number">(11)</span>Clause 2 provides:</p>
      
      <blockquote>"The Client [the Defendant] agrees to engage the Consultant [the Claimant] to provide technical consultancy services as may be required from time to time. The Client commits to a minimum annual engagement of 500 consultancy days per contract year at the Day Rate specified in Schedule 1."</blockquote>
      
      <p><span class="para-number">(12)</span>Schedule 1 specifies the "Day Rate" as £850.</p>
      
      <p><span class="para-number">(13)</span>Clause 8.2 provides:</p>
      
      <blockquote>"Either party may terminate this Agreement by giving not less than 90 days' written notice to the other party."</blockquote>
      
      <p><span class="para-number">(14)</span>No other provision of the Agreement addresses termination, minimum commitments, or the consequences of early termination.</p>
    </div>

    <div id="issues">
      <h2>IV. The Issues</h2>
      
      <p><span class="para-number">(15)</span>The principal issues for determination are:</p>
      
      <p><span class="para-number">(16)</span><strong>Issue 1:</strong> Whether, on its true construction, Clause 2 of the Agreement imposed upon the Defendant a binding obligation to purchase 500 consultancy days per contract year.</p>
      
      <p><span class="para-number">(17)</span><strong>Issue 2:</strong> If so, whether the Defendant's termination pursuant to Clause 8.2 relieved it of liability for the balance of that minimum commitment.</p>
      
      <p><span class="para-number">(18)</span><strong>Issue 3:</strong> If the Defendant is liable, what is the quantum of damages recoverable by the Claimant.</p>
    </div>

    <div id="positions">
      <h2>V. The Parties' Positions</h2>
      
      <p><span class="para-number">(19)</span><strong>The Claimant's submissions:</strong> The Claimant submits that the language of Clause 2 is clear and unambiguous. The word "commits" is mandatory and creates a binding obligation, not merely an aspiration or estimate. The phrase "minimum annual engagement" necessarily implies a floor below which the Defendant could not fall without breaching the Agreement.</p>
      
      <p><span class="para-number">(20)</span>Further, the Claimant contends that Clause 8.2 operates as a general termination right but does not absolve the Defendant from accrued obligations or obligations crystallised by the minimum commitment. To construe the termination clause as extinguishing liability for the minimum commitment would render Clause 2 commercially meaningless.</p>
      
      <p><span class="para-number">(21)</span><strong>The Defendant's submissions:</strong> The Defendant contends that the reference to a "minimum annual engagement" must be read in context. It submits that this language was included for budgeting and planning purposes only, to give the Claimant comfort as to likely volumes, but was not intended to create a binding take-or-pay obligation.</p>
      
      <p><span class="para-number">(22)</span>The Defendant further argues that if any minimum obligation exists, it was entirely extinguished by valid exercise of the termination right in Clause 8.2. On this analysis, termination on notice ends all future obligations under the Agreement, including any unperformed minimum commitment.</p>
    </div>

    <div id="analysis">
      <h2>VI. Analysis and Determination</h2>
      
      <p><span class="para-number">(23)</span><strong>Issue 1: Construction of Clause 2</strong></p>
      
      <p><span class="para-number">(24)</span>I begin with the well-established principles of contractual construction summarised in <em>Wood v Capita Insurance Services Ltd</em> [2017] UKSC 24. The court's task is to ascertain the objective meaning of the contractual language, considering the contract as a whole and the relevant factual matrix, but disregarding subjective intentions.</p>
      
      <p><span class="para-number">(25)</span>The natural and ordinary meaning of the language in Clause 2 is, in my judgment, clear. The Defendant "commits to" a "minimum annual engagement" of 500 days. The word "commits" is unequivocal and promissory in character. The phrase "minimum annual engagement" defines a quantitative floor.</p>
      
      <p><span class="para-number">(26)</span>I reject the Defendant's submission that this language was merely indicative or aspirational. If the parties had intended to express an estimate rather than a commitment, it would have been straightforward to use language such as "anticipates" or "expects to require approximately." They did not do so.</p>
      
      <p><span class="para-number">(27)</span>This interpretation is reinforced by commercial common sense. The Claimant was being asked to hold capacity and potentially decline other work to service the Defendant's requirements. A minimum commitment provided the Claimant with revenue certainty justifying that commercial risk. To construe Clause 2 as merely indicative would deprive it of practical content.</p>
      
      <p><span class="para-number">(28)</span>Accordingly, I find that Clause 2 imposed upon the Defendant a binding contractual obligation to purchase 500 consultancy days per contract year at the specified rate.</p>
      
      <p><span class="para-number">(29)</span><strong>Issue 2: Effect of Termination</strong></p>
      
      <p><span class="para-number">(30)</span>The Defendant exercised its right to terminate under Clause 8.2 on 15 March 2024, with effect from 30 April 2024. The question is whether that termination relieved the Defendant of liability for the shortfall in the minimum annual commitment.</p>
      
      <p><span class="para-number">(31)</span>In my judgment it did not. The minimum commitment in Clause 2 is an annual obligation. By 30 April 2024, some 15 months of the contract year had elapsed. The Defendant had purchased only 285 days against a pro-rated minimum obligation of approximately 625 days (500 days × 15/12 months). The shortfall had therefore already crystallised as an accrued liability.</p>
      
      <p><span class="para-number">(32)</span>The termination right in Clause 8.2 permits either party to bring future performance to an end. It does not, absent clear language, operate to extinguish accrued rights and liabilities. There is no such language here.</p>
      
      <p><span class="para-number">(33)</span>This analysis accords with principle. As Gloster LJ observed in <em>Brake Bros Ltd v Ungless Ltd</em> [2004] EWCA Civ 1598, a termination clause will not be construed as releasing accrued obligations unless it clearly so provides. Clause 8.2 contains no such provision.</p>
      
      <p><span class="para-number">(34)</span>I therefore find that the Defendant's termination did not discharge its liability for the minimum commitment shortfall.</p>
      
      <p><span class="para-number">(35)</span><strong>Issue 3: Quantum</strong></p>
      
      <p><span class="para-number">(36)</span>The Claimant claims damages of £212,500 representing 250 unpurchased days (500 minimum less 250 days actually purchased in the first contract year, being January to December 2023). However, the evidence shows that 285 days were actually purchased over the 15-month period ending 30 April 2024.</p>
      
      <p><span class="para-number">(37)</span>Calculating on an annual basis for the first contract year (January to December 2023), the shortfall was 250 days as claimed. At the contractual rate of £850 per day, this yields damages of £212,500.</p>
      
      <p><span class="para-number">(38)</span>The Claimant has not provided evidence of any steps taken to mitigate this loss, but equally the Defendant has not positively pleaded failure to mitigate. In the circumstances, I accept the Claimant's quantification.</p>
    </div>

    <div id="conclusion">
      <h2>VII. Conclusion on Liability</h2>
      
      <p><span class="para-number">(39)</span>For the reasons set out above, I find that:</p>
      
      <p><span class="para-number">(40)</span>(i) The Defendant was contractually obliged to purchase a minimum of 500 consultancy days per contract year pursuant to Clause 2 of the Agreement;</p>
      
      <p><span class="para-number">(41)</span>(ii) The Defendant breached that obligation by purchasing only 250 days in the first contract year;</p>
      
      <p><span class="para-number">(42)</span>(iii) The Defendant's termination pursuant to Clause 8.2 did not discharge its accrued liability for that breach; and</p>
      
      <p><span class="para-number">(43)</span>(iv) The Claimant is entitled to damages in the sum of £212,500.</p>
    </div>

    <div id="orders">
      <h2>VIII. Relief and Orders</h2>
      
      <p><span class="para-number">(44)</span>I will therefore make the following orders:</p>
      
      <p><span class="para-number">(45)</span>(1) Judgment for the Claimant in the sum of £212,500;</p>
      
      <p><span class="para-number">(46)</span>(2) Interest on that sum pursuant to section 35A of the Senior Courts Act 1981 at the rate of 8% per annum from the date of breach (1 January 2024) to the date of judgment;</p>
      
      <p><span class="para-number">(47)</span>(3) The Defendant shall pay the Claimant's costs of the claim, such costs to be assessed on the standard basis if not agreed;</p>
      
      <p><span class="para-number">(48)</span>(4) Permission to appeal is refused.</p>
      
      <div class="text-right mt-12 space-y-2">
        <div class="text-quantum-ice font-display uppercase tracking-wider">The Agentic Arbitral Tribunal</div>
        <div class="text-slate-400 font-mono text-sm">29 November 2025</div>
      </div>
    </div>
  `,
};

const Judgment = () => {
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState<string>("introduction");
  const sectionRefs = useRef<{ [key: string]: HTMLElement | null }>({});

  // Intersection observer to track active section
  useEffect(() => {
    const observerOptions = {
      root: null,
      rootMargin: "-20% 0px -70% 0px",
      threshold: 0,
    };

    const observerCallback = (entries: IntersectionObserverEntry[]) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          setActiveSection(entry.target.id);
        }
      });
    };

    const observer = new IntersectionObserver(observerCallback, observerOptions);

    // Observe all sections
    mockJudgment.sections.forEach((section) => {
      const element = document.getElementById(section.id);
      if (element) {
        sectionRefs.current[section.id] = element;
        observer.observe(element);
      }
    });

    return () => observer.disconnect();
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  const handleExportPDF = () => {
    console.log("Exporting judgment as PDF...");
  };

  const handleNewArbitration = () => {
    navigate("/upload");
  };

  return (
    <div className="min-h-screen bg-slate-900 flex">
      {/* Navigation Sidebar */}
      <aside className="w-56 bg-slate-900/80 border-r border-slate-800 sticky top-0 h-screen overflow-y-auto">
        <div className="p-6 border-b border-slate-800">
          <div className="flex items-center gap-2 text-quantum-ice">
            <FileText className="h-5 w-5" />
            <span className="font-display uppercase tracking-wider text-sm">Judgment</span>
          </div>
          <div className="mt-2 text-xs text-slate-400 font-mono">{mockJudgment.citation}</div>
        </div>

        <nav className="p-4 space-y-1">
          {mockJudgment.sections.map((section) => (
            <button
              key={section.id}
              onClick={() => scrollToSection(section.id)}
              className={`w-full text-left px-3 py-2 rounded text-sm transition-all duration-300 ${
                activeSection === section.id
                  ? "bg-quantum-ice/10 text-quantum-ice border-l-2 border-quantum-ice"
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/50"
              }`}
            >
              {section.title}
            </button>
          ))}
        </nav>
      </aside>

      {/* Main Document Area */}
      <main className="flex-1 overflow-y-auto">
        <div className="max-w-3xl mx-auto px-8 py-12">
          {/* Document Header */}
          <div className="mb-8 pb-6 border-b border-slate-800">
            <h1 className="text-2xl font-display uppercase tracking-wider text-plasma-white mb-2">
              Arbitral Award
            </h1>
            <div className="text-sm text-slate-400 space-y-1">
              <div>
                <span className="text-slate-500">Case:</span> {mockJudgment.claimant} v{" "}
                {mockJudgment.defendant}
              </div>
              <div>
                <span className="text-slate-500">Reference:</span> {mockJudgment.caseNumber}
              </div>
              <div>
                <span className="text-slate-500">Date:</span> {mockJudgment.date}
              </div>
            </div>
          </div>

          {/* Judgment Content */}
          <div
            className="judgment-document"
            dangerouslySetInnerHTML={{ __html: mockJudgment.content }}
          />
        </div>

        {/* Sticky Footer Actions */}
        <div className="sticky bottom-0 bg-slate-900/95 backdrop-blur border-t border-slate-800 p-6">
          <div className="max-w-3xl mx-auto flex gap-4 justify-end">
            <Button
              onClick={handleExportPDF}
              variant="outline"
              className="border-slate-700 hover:border-quantum-ice hover:bg-quantum-ice/5"
            >
              <FileDown className="mr-2 h-4 w-4" />
              Export PDF
            </Button>
            <Button
              onClick={handleNewArbitration}
              className="bg-quantum-ice text-obsidian hover:bg-quantum-ice/90"
            >
              <FileText className="mr-2 h-4 w-4" />
              New Arbitration
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Judgment;
