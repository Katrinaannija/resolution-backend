export type DemoDocument = {
  id: string;
  title: string;
  content: string;
  extension: string;
  wordCount: number;
  charCount: number;
  shortCode: string;
  path: string;
};

const documentModules = import.meta.glob<string>("@/types/documents/*", {
  eager: true,
  as: "raw",
});

export const demoDocuments: DemoDocument[] = Object.entries(documentModules)
  .map(([path, content]) => {
    const fileName = path.split("/").pop() ?? path;
    const [codePart, ...rest] = fileName.split(" - ");
    const title = rest.length > 0 ? rest.join(" - ").replace(/\.[^.]+$/, "").trim() : fileName.replace(/\.[^.]+$/, "");
    const extension = fileName.includes(".") ? fileName.split(".").pop() ?? "" : "";
    const wordCount = content.trim().length ? content.trim().split(/\s+/).length : 0;

    return {
      id: fileName,
      title: title || fileName,
      content,
      extension: extension.toUpperCase(),
      wordCount,
      charCount: content.length,
      shortCode: (codePart ?? fileName).trim(),
      path,
    };
  })
  .sort((a, b) => a.shortCode.localeCompare(b.shortCode));


