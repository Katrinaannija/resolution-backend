import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Submit from "./pages/Submit";
import ProcessingScreen, { LiveProcessingScreen } from "./pages/ProcessingScreen";
import JudgmentDemo, { LiveJudgmentScreen } from "./pages/JudgmentDemo";
import NotFound from "./pages/NotFound";
import DocumentInspector from "./pages/DocumentInspector";

const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <BrowserRouter>
          <Toaster />
          <Sonner />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/submit" element={<Submit />} />
            
            {/* Demo Flow */}
            <Route path="/processing" element={<ProcessingScreen />} />
            <Route path="/judgment" element={<JudgmentDemo />} />
            <Route path="/documents" element={<DocumentInspector />} />
            <Route path="/live/processing" element={<LiveProcessingScreen />} />
            <Route path="/live/judgement" element={<LiveJudgmentScreen />} />
            
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
