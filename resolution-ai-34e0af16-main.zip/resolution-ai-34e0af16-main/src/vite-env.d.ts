/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_LIVE_EVENTS_ENDPOINT?: string;
  readonly VITE_LIVE_AGENT_BASE_URL?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
